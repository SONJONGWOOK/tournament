import img1 from '../onepiece/1.jpg'
import img2 from '../onepiece/2.jpg'
import img3 from '../onepiece/3.jpg'
import img4 from '../onepiece/4.jpg'
import img5 from '../onepiece/5.jpg'
import img6 from '../onepiece/6.jpg'
import img7 from '../onepiece/7.jpg'
import img8 from '../onepiece/8.jpg'
import img9 from '../onepiece/9.jpg'
import img10 from '../onepiece/10.jpg'
import img11 from '../onepiece/11.jpg'
import img12 from '../onepiece/12.jpg'
import img13 from '../onepiece/13.jpg'
import img14 from '../onepiece/14.jpg'
import img15 from '../onepiece/15.jpg'
import img16 from '../onepiece/16.jpg'
import img17 from '../onepiece/17.jpg'
import img18 from '../onepiece/18.jpg'
import img19 from '../onepiece/19.jpg'
import img20 from '../onepiece/20.jpg'
import img21 from '../onepiece/21.jpg'
import img22 from '../onepiece/22.jpg'
import img23 from '../onepiece/23.jpg'
import img24 from '../onepiece/24.jpg'
import img25 from '../onepiece/25.jpg'
import img26 from '../onepiece/26.jpg'
import img27 from '../onepiece/27.jpg'
import img28 from '../onepiece/28.jpg'
import img29 from '../onepiece/29.jpg'
import img30 from '../onepiece/30.jpg'
import img31 from '../onepiece/31.jpg'
import img32 from '../onepiece/32.jpg'
import img33 from '../onepiece/33.jpg'
import img34 from '../onepiece/34.jpg'
import img35 from '../onepiece/35.jpg'
import img36 from '../onepiece/36.jpg'
import img37 from '../onepiece/37.jpg'
import img38 from '../onepiece/38.jpg'
import img39 from '../onepiece/39.jpg'
import img40 from '../onepiece/40.jpg'
import img41 from '../onepiece/41.jpg'
import img42 from '../onepiece/42.jpg'
import img43 from '../onepiece/43.jpg'
import img44 from '../onepiece/44.jpg'
import img45 from '../onepiece/45.jpg'
import img46 from '../onepiece/46.jpg'
import img47 from '../onepiece/47.jpg'
import img48 from '../onepiece/48.jpg'
import img49 from '../onepiece/49.jpg'
import img50 from '../onepiece/50.jpg'
import img51 from '../onepiece/51.jpg'
import img52 from '../onepiece/52.jpg'
import img53 from '../onepiece/53.jpg'
import img54 from '../onepiece/54.jpg'
import img55 from '../onepiece/55.jpg'
import img56 from '../onepiece/56.jpg'
import img57 from '../onepiece/57.jpg'
import img58 from '../onepiece/58.jpg'
import img59 from '../onepiece/59.jpg'
import img60 from '../onepiece/60.jpg'
import img61 from '../onepiece/61.jpg'
import img62 from '../onepiece/62.jpg'
import img63 from '../onepiece/63.jpg'
import img64 from '../onepiece/64.jpg'



const onepiece = () =>{
    return [
         { name : '루피',               path : img1  } ,
         { name : '부룩',               path : img2  } ,
         { name : '조로',               path : img3  } ,
         { name : '로빈',               path : img4  } ,
         { name : '흰수염',             path : img5  } ,
         { name : '프랑키',             path : img6  } ,
         { name : '나미',               path : img7 } ,
         { name : '상디',               path : img8 } ,
         { name : '상크스',             path : img9  } ,
         { name : '유스타스',           path : img10  } ,
         { name : '검은수염',           path : img11  } ,
         { name : '로저',               path : img12  } ,
         { name : '레일리',             path : img13  } ,
         { name : '몽블랑노랜드',        path : img14  } ,
         { name : '샬롯링링',            path : img15 } ,
         { name : '카이도',              path : img16 } ,
         { name : '에이스',              path : img17 } ,
         { name : '마르코',              path : img18 } ,
         { name : '바제스',              path : img19 } ,
         { name : '시류',                path : img20 } ,
         { name : '라피트',              path : img21 } ,
         { name : '반오거',              path : img22 } ,
         { name : '사도크Q',             path : img23 } ,
         { name : '로우',                path : img24 } ,
         { name : '호킨스',              path : img25 } ,
         { name : '아푸',                path : img26 } ,
         { name : '우르지',              path : img27 } ,
         { name : '보니',                path : img28 } ,
         { name : '카리브',              path : img29 } ,
         { name : '아카이누',            path : img30 } ,
         { name : '센고쿠',              path : img31 } ,
         { name : '후지토라',            path : img32 } ,
         { name : '아오키지',            path : img33 } ,
         { name : '가프',               path : img34 } ,
         { name : '코비',               path : img35 } ,
         { name : '로시난테',            path : img36 } ,
         { name : '미호크',              path : img37 } ,
         { name : '크로커다일',            path : img38 } ,
         { name : '도플라밍고',           path : img39 } ,
         { name : '쿠마',                path : img40 } ,
         { name : '행콕',            path : img41 } ,
         { name : '겟코모리아',       path : img42 } ,
         { name : '버기',            path : img43 } ,
         { name : '로브루치',                path : img44 } ,
         { name : '마젤란',            path : img45 } ,
         { name : '사보',       path : img46 } ,
         { name : '이반코브',            path : img47 } ,
         { name : '코알라',                path : img48 } ,
         { name : '제프',            path : img49 } ,
         { name : '카쿠',       path : img50 } ,
         { name : '징베',            path : img51 } ,
         { name : '헤르메포',       path : img52 } ,
         { name : '키자루',            path : img53 } ,
         { name : '에넬',       path : img54 } ,
         { name : '비비',            path : img55 } ,
         { name : '아이스버그',       path : img56 } ,
         { name : '시라호시',            path : img57 } ,
         { name : '레베카',            path : img58 } ,
         { name : '킨에몬',            path : img59 } ,
         { name : '이누아라시',            path : img60 } ,
         { name : '네코마무시',            path : img61 } ,
         { name : '우솝',            path : img62 } ,
         { name : '벤베크만',            path : img63 } ,
         { name : '쵸파',            path : img64 } ,
  
    ]
} 

export {onepiece}