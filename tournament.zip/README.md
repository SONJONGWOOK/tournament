# tournament

## 이상형 월드컵

### ● 토너먼트 형태로 A vs B 형태로 대전중인것을 확인할 수있어야함
#### ○ A와 B중 하나 선택
##### - 짝수로 진행(ex 32강 -> 16강 -> 8강 -> 4강 -> 결승전)
##### - 최종 이상형이 선택 될때까지 계속 
##### - 부전승 없음
#### ○ 이상형을 선택한 후 되돌아 갈 수 있다
##### - 강 전환 여부 상관없이 취소 할수있음
##### - 최종 이상형을 뽑은후(결승전) 취소 불가능
#### ○ 강 전환시 이상형은 랜덤으로 섞어야함
##### - 단 취소시에는 이전 단계는 섞이지 않고 유지되어야함.
#### ○ 우승자와 히스토리를 확인할 수 있어야함
##### - 히스토리는 트리형태로 구성.

## 초기 컨셉 
### 만화케릭터 64개를 놓고 무작위 64강부터 8강까지 선택할 수 있게 함.
### 라운드 선택 기능
### 히스토리 기능
### 뒤로가기 기능

## lang
### HTML , CSS
### Javascript

## stack
### webpack , fileloader
### babel , bable-poyfill

## file
### index.html , /dist/css/index.css , /dist/css/tree.css , /dist/font/SDSwaggerTTF.woff
### /src/js/entry.js , /src/js/comic.js , /src/js/tree.js , /src/js/utile.js , /dist/bundel.js 
### img - /dist/src/img ... 




